hello ms wong

HOW TO PLAY
=======================================================================================================
WASD to move
Space/Left click to shoot
I to toggle autofire (recommended that you keep this on)
E to cast ability
P to pause game
Aim with mouse
Items can be swapped by clicking two squares or right clicking

The game is time-based, so the goal is to complete it as fast as possible :)


MISSING FUNCTIONALITIES
=======================================================================================================
Currently, the game consists of four dungeon "levels"
0: Silent Sands, 1: Wild Wetlands, 2: Volatile Volcano, 3: Corrupted Catacombs

The final level is missing an actual boss fight. Instead, a miniboss (Lost Sentinel) is placed
at the end of the level. After defeating it, a portal to the "inner sanctum" is dropped, which
should lead to the boss fight. Since I don't have time, the game is won instead.

The intended boss fight for Corrupted Catacombs is the Pannion Seer, whose concept would've been
taken from Malazan, Book of the Fallen. Would've been nice to make but no time so

I was also going to add an optional "treasure room" boss to the Corrupted Catacombs but again, 
no time :(

Don't know if this counts as a functionality, but the game is pretty poorly balanced so maybe
some classes or items are overpowered or out of place. I haven't had the time to sufficiently
balance or test the game

KNOWN BUGS
=======================================================================================================
Surprisingly, there are no known major bugs in the 28,000 lines of code here   B)

However, there are some minor ones:

Some enemies in the Wild Wetlands will have weird interactions with walls and their hover animations,
this is because the hover movement does not check for collision. I don't know why I haven't fixed this
to be honest

When pausing the game, bomb throwing projectiles will still animate but stay in place. This is because
I don't check the game state when randomly generating particle locations

In the Volatile Volcano, some rooms will have a slight overlap. This bug will be hard to find unless 
you're walking deep into lava, which you'd never do anyways. This could be fixed by making the hallways
between rooms longer, but I don't think it's worth it

There might be a really really small (and I mean really small) chance that "claw" shaped rooms in the
Corrupted Catacombs will have a gap where you can leave the map completely. That being said, the hole 
in the "claw" looks nice and you don't get any advantage from leaving the map, so whatever

When boss fights are initiated, it closes off the room. It's theoretically possible to trap an enemy
in that wall, but I haven't been able to actually do it yet. 

Also, while enemies cannot shoot projectiles over the wall, enemies can still throw bombs. This is a 
bit of a problem in the Lost Sentinel boss fight, where a mammoth hunter can stand on the other side 
and throw dazing grendes over the wall. Not sure what the solution would even be for this problem, 
maybe despawn enemies within a certain radius? 

IMPORTANT INFO
=======================================================================================================
src/control/Driver.java is the "main" class

Classes I Commented:
src/control/Controller.java
src/control/Driver.java
src/project/Enemy.java
src/project/Projectile.java
src/player/Player.java
src/project/Equipment.java
src/project/Area.java

Use of Important Concepts:
Stack: src/control/Controller.java - stacks are used to temporarily copy enemies and projectiles for
later use to prevent ConcurrentModification errors
ArrayList: used pretty much everywhere from projectiles to enemies to areas to dungeons to items
LinkedList: also used in many places where I don't need random access
Sorting/Comparator/PriorityQueue: used for AoE depth, "higher" shots are drawn first
Actual Comparator: src/project/PlayerInfo.java - used to sort players in the TreeSet
Actual Sorting: src/control/Driver.java - used to find the most frequent enemy killed
HashMap: src/player/Player.java - used to keep track of what enemies were killed and the most 
frequent enemy killed
BinarySearch: src/project/Dungeon.java - used to make sure consecutive rooms are different

In the version that I'm uploading, you'll spawn with a ring called the "Mechanical Ring".
This is my "cheat" version: it gives you insane amounts of survivability and damage with the added
perk of doubling all xp gains. Don't take it off as it's way stronger than any other ring in the 
game.

In my Controller class (src/control/Controller), there's a "fixGame" method, where you can add
whatever items or levels or portals you want, but I don't think you'll need that


